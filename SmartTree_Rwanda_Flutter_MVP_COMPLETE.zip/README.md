# SmartTree Rwanda Flutter MVP v0.1
This is a student prototype for offline tree registration and monitoring.

Features: tree ID, species, location description, optional planting date, monitoring date, height, general condition, symptom notes, tree list, history, delete, English/Kinyarwanda, SQLite local storage.

Not included: GPS, photos, export, login, cloud backup or online sync. Language selection resets to English after restart. Records are stored only on this phone and may be lost if app data is cleared or the app is uninstalled. Observed symptoms are not a confirmed diagnosis. Obtain permission before field data collection.

Build on a computer:
```bash
flutter create --platforms=android .
flutter pub get
flutter analyze
flutter test
flutter run
flutter build apk --release
```
See `BUILD_APK_WITH_GITHUB.md` for phone-only GitHub Actions instructions.
