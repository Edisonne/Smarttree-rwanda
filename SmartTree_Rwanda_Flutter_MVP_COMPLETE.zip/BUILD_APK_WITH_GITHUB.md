# Phone-only GitHub APK build

1. Download this project ZIP to your Android phone.
2. Sign in at https://github.com and create a repository named `SmartTree-Rwanda`.
3. In the new repository choose **Add file > Upload files** and upload the downloaded ZIP file. Rename it `smarttree-source.zip` before uploading if necessary. Commit the upload.
4. In the repository choose **Add file > Create new file**.
5. In the filename field enter exactly `.github/workflows/build-android-apk.yml` (GitHub creates the folders).
6. Open `GITHUB_WORKFLOW_CONTENT.txt` from the extracted project package and copy all its contents into the new GitHub file. Alternatively copy the workflow from the instructions supplied with this package.
7. Commit the new workflow file to the `main` branch.
8. Open the repository's **Actions** tab. Select **Build SmartTree Rwanda Android APK**, tap **Run workflow**, choose `main`, then confirm.
9. Wait for the run. A green check means the build completed. Open the run and download the `smarttree-rwanda-android-apk` artifact.
10. Extract the downloaded artifact ZIP. It contains `app-release.apk`. Tap it to install. Android may ask you to allow installs from your browser or file manager.

Important: uploading the project ZIP alone does not run GitHub Actions. The workflow file must be created in the repository at `.github/workflows/build-android-apk.yml`. This workflow extracts the uploaded ZIP and compiles the app in GitHub's cloud environment.
