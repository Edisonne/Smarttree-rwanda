import 'package:flutter/material.dart';
import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart' as path;

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Store.db;
  runApp(const SmartTreeApp());
}

enum Lang { en, rw }

String tr(Lang l, String key) {
  const m = <String, List<String>>{
    'app': ['SmartTree Rwanda', 'SmartTree Rwanda'],
    'dashboard': ['Dashboard', 'Ahabanza'], 'trees': ['Trees', 'Ibiti'],
    'settings': ['Settings', 'Igenamiterere'], 'register': ['Register a tree', 'Andikisha igiti'],
    'monitor': ['Add monitoring record', 'Ongeraho igenzura'], 'treeId': ['Tree ID (e.g. AV-001)', 'Kode y’igiti (urugero AV-001)'],
    'species': ['Species', 'Ubwoko bw’igiti'], 'location': ['Location description', 'Aho giherereye'],
    'planting': ['Planting date (optional)', 'Itariki cyateweho (si ngombwa)'],
    'height': ['Height in metres', 'Uburebure muri metero'], 'condition': ['Tree condition', 'Imimerere y’igiti'],
    'symptoms': ['Visible symptoms / notes', 'Ibimenyetso / ibisobanuro'], 'date': ['Observation date', 'Itariki yo kugenzura'],
    'healthy': ['Healthy', 'Kimeze neza'], 'fair': ['Fair', 'Kiringaniye'], 'poor': ['Poor', 'Kimeze nabi'],
    'unknown': ['Unknown', 'Ntibizwi'], 'save': ['Save', 'Bika'], 'cancel': ['Cancel', 'Hagarika'],
    'noTrees': ['No trees yet. Register your first tree.', 'Nta biti birandikwa. Andika igiti cya mbere.'],
    'noVisits': ['No monitoring records yet.', 'Nta nyandiko zo kugenzura zirahari.'],
    'registered': ['Registered trees', 'Ibiti byanditswe'], 'records': ['Monitoring records', 'Inyandiko zo kugenzura'],
    'offline': ['Offline storage is active. Records are saved on this phone.', 'Amakuru abikwa muri telefoni kandi porogaramu ikora nta murandasi.'],
    'sync': ['Online synchronisation is not included yet.', 'Guhuza amakuru kuri murandasi ntibirashyirwamo.'],
    'language': ['App language', 'Ururimi rwa porogaramu'], 'english': ['English', 'Icyongereza'],
    'kinyarwanda': ['Kinyarwanda', 'Ikinyarwanda'], 'delete': ['Delete tree', 'Siba igiti'],
    'confirm': ['Delete this tree and its monitoring records?', 'Siba iki giti n’inyandiko zacyo?'],
    'success': ['Saved successfully', 'Byabitswe neza'], 'required': ['Complete the required fields.', 'Uzuza ahasabwa.'],
    'prototype': ['Student prototype • Version 0.1', 'Igerageza ry’umunyeshuri • Verisiyo 0.1'],
  };
  return m[key]?[l == Lang.en ? 0 : 1] ?? key;
}

class Tree {
  final int? id; final String code, species, location, planting;
  Tree({this.id, required this.code, required this.species, required this.location, required this.planting});
  Map<String,Object?> map() => {'code':code,'species':species,'location':location,'planting':planting};
  factory Tree.from(Map<String,Object?> m) => Tree(id:m['id'] as int,code:m['code'] as String,species:m['species'] as String,location:m['location'] as String,planting:m['planting'] as String? ?? '');
}
class Visit {
  final int? id; final int treeId; final String date,height,condition,symptoms;
  Visit({this.id,required this.treeId,required this.date,required this.height,required this.condition,required this.symptoms});
  Map<String,Object?> map()=>{'tree_id':treeId,'date':date,'height':height,'condition':condition,'symptoms':symptoms};
  factory Visit.from(Map<String,Object?> m)=>Visit(id:m['id'] as int,treeId:m['tree_id'] as int,date:m['date'] as String,height:m['height'] as String? ?? '',condition:m['condition'] as String,symptoms:m['symptoms'] as String? ?? '');
}
class Store {
  static Database? _db;
  static Future<Database> get db async {
    if (_db != null) return _db!;
    final dir=await getDatabasesPath();
    _db=await openDatabase(path.join(dir,'smarttree_rwanda.db'),version:1,onCreate:(d,v) async {
      await d.execute('CREATE TABLE trees(id INTEGER PRIMARY KEY AUTOINCREMENT, code TEXT UNIQUE NOT NULL, species TEXT NOT NULL, location TEXT NOT NULL, planting TEXT)');
      await d.execute('CREATE TABLE visits(id INTEGER PRIMARY KEY AUTOINCREMENT, tree_id INTEGER NOT NULL, date TEXT NOT NULL, height TEXT, condition TEXT NOT NULL, symptoms TEXT)');
    });
    return _db!;
  }
  static Future<List<Tree>> trees() async => (await (await db).query('trees',orderBy:'code')).map(Tree.from).toList();
  static Future<List<Visit>> visits(int id) async => (await (await db).query('visits',where:'tree_id=?',whereArgs:[id],orderBy:'date DESC')).map(Visit.from).toList();
  static Future<void> addTree(Tree t) async => (await db).insert('trees',t.map());
  static Future<void> addVisit(Visit v) async => (await db).insert('visits',v.map());
  static Future<int> countVisits() async { final r=await (await db).rawQuery('SELECT COUNT(*) AS n FROM visits'); return Sqflite.firstIntValue(r)??0; }
  static Future<void> deleteTree(int id) async { final d=await db; await d.transaction((tx) async { await tx.delete('visits',where:'tree_id=?',whereArgs:[id]); await tx.delete('trees',where:'id=?',whereArgs:[id]); }); }
}

class SmartTreeApp extends StatefulWidget { const SmartTreeApp({super.key}); @override State<SmartTreeApp> createState()=>_AppState(); }
class _AppState extends State<SmartTreeApp> {
  Lang lang=Lang.en;
  @override Widget build(BuildContext context)=>MaterialApp(debugShowCheckedModeBanner:false,title:'SmartTree Rwanda',
    theme:ThemeData(colorScheme:ColorScheme.fromSeed(seedColor:const Color(0xff246b45)),useMaterial3:true),
    home:Home(lang:lang,onLang:(v)=>setState(()=>lang=v)));
}
class Home extends StatefulWidget {
  final Lang lang; final ValueChanged<Lang> onLang;
  const Home({super.key,required this.lang,required this.onLang});
  @override State<Home> createState()=>_HomeState();
}
class _HomeState extends State<Home> {
  int tab=0; String t(String k)=>tr(widget.lang,k); void refresh()=>setState((){});
  @override Widget build(BuildContext context) {
    final pages=[dashboard(),TreeList(lang:widget.lang,changed:refresh),Settings(lang:widget.lang,onLang:widget.onLang)];
    return Scaffold(appBar:AppBar(title:const Row(children:[Icon(Icons.park,color:Color(0xff246b45)),SizedBox(width:8),Text('SmartTree Rwanda')])),
      body:pages[tab],
      floatingActionButton:tab<2?FloatingActionButton.extended(onPressed:() async {final ok=await Navigator.push<bool>(context,MaterialPageRoute(builder:(_)=>Register(lang:widget.lang)));if(ok==true)refresh();},icon:const Icon(Icons.add),label:Text(t('register'))):null,
      bottomNavigationBar:NavigationBar(selectedIndex:tab,onDestinationSelected:(v)=>setState(()=>tab=v),destinations:[
        NavigationDestination(icon:const Icon(Icons.dashboard_outlined),label:t('dashboard')),
        NavigationDestination(icon:const Icon(Icons.forest_outlined),label:t('trees')),
        NavigationDestination(icon:const Icon(Icons.settings_outlined),label:t('settings')),
      ]));
  }
  Widget dashboard()=>FutureBuilder<List<dynamic>>(future:Future.wait([Store.trees(),Store.countVisits()]),builder:(context,s){
    final ts=s.data==null?<Tree>[]:s.data![0] as List<Tree>; final n=s.data==null?0:s.data![1] as int;
    return ListView(padding:const EdgeInsets.all(16),children:[
      Container(padding:const EdgeInsets.all(22),decoration:BoxDecoration(borderRadius:BorderRadius.circular(20),gradient:const LinearGradient(colors:[Color(0xff174d35),Color(0xff38865b)])),
        child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[const Icon(Icons.eco,color:Colors.white,size:34),const SizedBox(height:10),Text(t('app'),style:const TextStyle(color:Colors.white,fontSize:24,fontWeight:FontWeight.bold)),Text(t('prototype'),style:const TextStyle(color:Colors.white70))])),
      const SizedBox(height:14),Row(children:[Expanded(child:stat(t('registered'),ts.length,Icons.park)),const SizedBox(width:12),Expanded(child:stat(t('records'),n,Icons.fact_check))]),
      const SizedBox(height:14),Card(child:Padding(padding:const EdgeInsets.all(16),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(t('offline')),const SizedBox(height:8),Text(t('sync'))]))),
      const SizedBox(height:14),Text(t('trees'),style:Theme.of(context).textTheme.titleLarge),
      if(ts.isEmpty)Padding(padding:const EdgeInsets.all(20),child:Text(t('noTrees'))) else ...ts.take(6).map((x)=>Card(child:ListTile(leading:const CircleAvatar(child:Icon(Icons.park)),title:Text(x.code),subtitle:Text('${x.species} • ${x.location}'),onTap:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>Details(tree:x,lang:widget.lang,changed:refresh)))))),
      const SizedBox(height:80)]);
  });
  Widget stat(String label,int value,IconData icon)=>Card(child:Padding(padding:const EdgeInsets.all(14),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Icon(icon,color:const Color(0xff246b45)),Text('$value',style:const TextStyle(fontSize:27,fontWeight:FontWeight.bold)),Text(label)])));
}
class Register extends StatefulWidget { final Lang lang; const Register({super.key,required this.lang}); @override State<Register> createState()=>_RegisterState(); }
class _RegisterState extends State<Register> {
  final form=GlobalKey<FormState>(); final code=TextEditingController(),species=TextEditingController(),location=TextEditingController(),planting=TextEditingController();
  String t(String k)=>tr(widget.lang,k);
  @override void dispose(){code.dispose();species.dispose();location.dispose();planting.dispose();super.dispose();}
  Widget field(TextEditingController c,String label,{bool required=true})=>Padding(padding:const EdgeInsets.only(bottom:13),child:TextFormField(controller:c,decoration:InputDecoration(labelText:label,border:const OutlineInputBorder()),validator:(v)=>required&&(v==null||v.trim().isEmpty)?t('required'):null));
  @override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:Text(t('register'))),body:Form(key:form,child:ListView(padding:const EdgeInsets.all(16),children:[
    field(code,t('treeId')),field(species,t('species')),field(location,t('location')),field(planting,t('planting'),required:false),
    FilledButton.icon(onPressed:save,icon:const Icon(Icons.save),label:Text(t('save')))])));
  Future<void> save() async {if(!form.currentState!.validate())return;try{await Store.addTree(Tree(code:code.text.trim().toUpperCase(),species:species.text.trim(),location:location.text.trim(),planting:planting.text.trim()));if(!mounted)return;ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(t('success'))));Navigator.pop(context,true);}catch(_){if(!mounted)return;ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Tree ID already exists or could not be saved.')));}}
}
class TreeList extends StatefulWidget { final Lang lang; final VoidCallback changed; const TreeList({super.key,required this.lang,required this.changed}); @override State<TreeList> createState()=>_TreeListState(); }
class _TreeListState extends State<TreeList> {
  @override Widget build(BuildContext context)=>FutureBuilder<List<Tree>>(future:Store.trees(),builder:(context,s){final ts=s.data??[];if(ts.isEmpty)return Center(child:Text(tr(widget.lang,'noTrees')));return ListView.builder(padding:const EdgeInsets.all(12),itemCount:ts.length,itemBuilder:(context,i){final x=ts[i];return Card(child:ListTile(leading:const CircleAvatar(child:Icon(Icons.park)),title:Text(x.code),subtitle:Text('${x.species}\\n${x.location}'),isThreeLine:true,onTap:()async{await Navigator.push(context,MaterialPageRoute(builder:(_)=>Details(tree:x,lang:widget.lang,changed:widget.changed)));if(mounted)setState((){});}));});});
}
class Details extends StatefulWidget { final Tree tree; final Lang lang; final VoidCallback changed; const Details({super.key,required this.tree,required this.lang,required this.changed}); @override State<Details> createState()=>_DetailsState(); }
class _DetailsState extends State<Details> {
  String t(String k)=>tr(widget.lang,k);
  @override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:Text(widget.tree.code),actions:[IconButton(onPressed:delete,icon:const Icon(Icons.delete_outline))]),
    floatingActionButton:FloatingActionButton.extended(onPressed:addVisit,icon:const Icon(Icons.add_chart),label:Text(t('monitor'))),
    body:FutureBuilder<List<Visit>>(future:Store.visits(widget.tree.id!),builder:(context,s){final vs=s.data??[];return ListView(padding:const EdgeInsets.all(16),children:[
      Card(child:Padding(padding:const EdgeInsets.all(16),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(widget.tree.species,style:Theme.of(context).textTheme.titleLarge),Text('Location: ${widget.tree.location}'),Text('Planting: ${widget.tree.planting.isEmpty?'—':widget.tree.planting}')]))),
      Text(t('records'),style:Theme.of(context).textTheme.titleLarge),if(vs.isEmpty)Text(t('noVisits')) else ...vs.map((v)=>Card(child:ListTile(leading:const Icon(Icons.monitor_heart),title:Text('${v.date} • ${t(v.condition)}'),subtitle:Text('Height: ${v.height.isEmpty?'—':'${v.height} m'}\\n${v.symptoms}'),isThreeLine:true))),const SizedBox(height:80)]);} ));
  Future<void> addVisit()async{final ok=await Navigator.push<bool>(context,MaterialPageRoute(builder:(_)=>AddVisit(tree:widget.tree,lang:widget.lang)));if(ok==true&&mounted){setState((){});widget.changed();}}
  Future<void> delete()async{final yes=await showDialog<bool>(context:context,builder:(_)=>AlertDialog(title:Text(t('delete')),content:Text(t('confirm')),actions:[TextButton(onPressed:()=>Navigator.pop(context,false),child:Text(t('cancel'))),FilledButton(onPressed:()=>Navigator.pop(context,true),child:Text(t('delete')))]));if(yes==true){await Store.deleteTree(widget.tree.id!);widget.changed();if(mounted)Navigator.pop(context);}}
}
class AddVisit extends StatefulWidget { final Tree tree; final Lang lang; const AddVisit({super.key,required this.tree,required this.lang}); @override State<AddVisit> createState()=>_AddVisitState(); }
class _AddVisitState extends State<AddVisit> {
  final form=GlobalKey<FormState>(); final height=TextEditingController(),symptoms=TextEditingController(); String condition='healthy'; DateTime date=DateTime.now(); String t(String k)=>tr(widget.lang,k);
  @override void dispose(){height.dispose();symptoms.dispose();super.dispose();}
  @override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:Text(t('monitor'))),body:Form(key:form,child:ListView(padding:const EdgeInsets.all(16),children:[
    ListTile(leading:const Icon(Icons.park),title:Text(widget.tree.code),subtitle:Text(widget.tree.species)),
    InputDecorator(decoration:InputDecoration(labelText:t('date'),border:const OutlineInputBorder()),child:Row(children:[Expanded(child:Text('${date.year}-${date.month.toString().padLeft(2,'0')}-${date.day.toString().padLeft(2,'0')}')),IconButton(onPressed:pickDate,icon:const Icon(Icons.calendar_month))])),
    const SizedBox(height:12),TextFormField(controller:height,keyboardType:const TextInputType.numberWithOptions(decimal:true),decoration:InputDecoration(labelText:t('height'),border:const OutlineInputBorder()),validator:(v)=>v!=null&&v.trim().isNotEmpty&&double.tryParse(v.trim())==null?'Enter a number':null),
    const SizedBox(height:12),DropdownButtonFormField<String>(value:condition,decoration:InputDecoration(labelText:t('condition'),border:const OutlineInputBorder()),items:['healthy','fair','poor','unknown'].map((x)=>DropdownMenuItem(value:x,child:Text(t(x)))).toList(),onChanged:(v)=>setState(()=>condition=v??'unknown')),
    const SizedBox(height:12),TextFormField(controller:symptoms,maxLines:4,decoration:InputDecoration(labelText:t('symptoms'),border:const OutlineInputBorder())),
    const SizedBox(height:16),FilledButton.icon(onPressed:save,icon:const Icon(Icons.save),label:Text(t('save')))])));
  Future<void> pickDate()async{final d=await showDatePicker(context:context,initialDate:date,firstDate:DateTime(2000),lastDate:DateTime(2100));if(d!=null)setState(()=>date=d);}
  Future<void> save()async{if(!form.currentState!.validate())return;final ds='${date.year}-${date.month.toString().padLeft(2,'0')}-${date.day.toString().padLeft(2,'0')}';await Store.addVisit(Visit(treeId:widget.tree.id!,date:ds,height:height.text.trim(),condition:condition,symptoms:symptoms.text.trim()));if(!mounted)return;ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(t('success'))));Navigator.pop(context,true);}
}
class Settings extends StatelessWidget { final Lang lang; final ValueChanged<Lang> onLang; const Settings({super.key,required this.lang,required this.onLang}); @override Widget build(BuildContext context)=>ListView(padding:const EdgeInsets.all(16),children:[
  Text(tr(lang,'settings'),style:Theme.of(context).textTheme.headlineSmall),Card(child:Column(children:[
    ListTile(title:Text(tr(lang,'language'))),
    RadioListTile<Lang>(value:Lang.en,groupValue:lang,title:Text(tr(lang,'english')),onChanged:(v){if(v!=null)onLang(v);}),
    RadioListTile<Lang>(value:Lang.rw,groupValue:lang,title:Text(tr(lang,'kinyarwanda')),onChanged:(v){if(v!=null)onLang(v);})])),
  Card(child:Padding(padding:const EdgeInsets.all(16),child:Text(tr(lang,'offline')))),
  Card(child:Padding(padding:const EdgeInsets.all(16),child:Text(tr(lang,'sync')))),
  Center(child:Text(tr(lang,'prototype')))]);
}
